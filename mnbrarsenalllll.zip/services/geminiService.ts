
import { GoogleGenAI, Type } from "@google/genai";
import { AISuggestion } from "../types";

// Always initialize the Gemini client with the named parameter apiKey from process.env.API_KEY.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getDesignSuggestions = async (content: string): Promise<AISuggestion | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `بناءً على هذا النص الرياضي: "${content}"، اقترح قيم التصميم التالية باللغة الإنجليزية في صيغة JSON:
      1. mainTextSize (رقم بين 40 و 100)
      2. quoteTextSize (رقم بين 24 و 48)
      3. primaryColor (كود هيكس لوني مناسب للمحتوى)
      4. fontFamily (اختر واحداً من: Cairo, Tajawal, Almarai)`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            mainTextSize: { type: Type.NUMBER },
            quoteTextSize: { type: Type.NUMBER },
            primaryColor: { type: Type.STRING },
            fontFamily: { type: Type.STRING },
          },
          required: ["mainTextSize", "quoteTextSize", "primaryColor", "fontFamily"]
        }
      }
    });

    // Directly access the text property of the response.
    const result = JSON.parse(response.text || '{}');
    return result as AISuggestion;
  } catch (error) {
    console.error("AI Suggestion Error:", error);
    return null;
  }
};

export const generateSocialCaption = async (urgent: string, content: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `قم بصياغة نص منشور احترافي لمنصة إنستغرام وتويتر بناءً على الخبر التالي:
      العنوان: ${urgent}
      الخبر: ${content}
      
      المتطلبات:
      1. أسلوب مشوق وجذاب.
      2. استخدام إيموجي مناسبة للرياضة.
      3. إضافة هاشتاجات رياضية عالمية وعربية شائعة وهاشتاج خاص بنادي أرسنال.
      4. النص يجب أن يكون باللغة العربية الفصحى الحديثة.`,
    });
    return response.text || "حدث خطأ أثناء توليد النص.";
  } catch (error) {
    console.error("Caption Generation Error:", error);
    return "فشل توليد النص المساعد.";
  }
};
